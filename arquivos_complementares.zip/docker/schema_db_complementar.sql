begin;

alter table tbl_oscar add column location text null;
alter table tbl_movie add column code varchar(255) not null;
alter table tbl_movie add unique (code);

commit;
